execute if score @s[tag=!hastegenesis_no_cooldowns] hastegenesis_cooldown_life_gem_left_click matches 1.. run return fail
scoreboard players set @s hastegenesis_cooldown_life_gem_left_click 120


execute as @e[distance=0.01..15] run damage @s 5 minecraft:magic
effect give @s minecraft:instant_health 1 0 true
