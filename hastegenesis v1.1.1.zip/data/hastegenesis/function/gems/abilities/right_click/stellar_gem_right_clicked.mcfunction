advancement revoke @s only hastegenesis:right_click_stellar_gem

execute if score @s[tag=!hastegenesis_no_cooldowns] hastegenesis_cooldown_stellar_gem_right_click matches 1.. run return fail
scoreboard players set @s hastegenesis_cooldown_stellar_gem_right_click 10

#tellraw @a "right clicked stellar"