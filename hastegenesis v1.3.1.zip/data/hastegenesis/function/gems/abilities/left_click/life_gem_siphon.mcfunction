
$execute as @s run effect give @s absorption 120 $(number) false