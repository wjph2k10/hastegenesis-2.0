execute as @s at @s run effect give @s minecraft:hunger 1 4 true
execute as @s at @s run execute as @e[distance=0.1..10] run effect give @s minecraft:slowness 1 1 true
execute as @s at @s run execute as @e[distance=0.1..10] run effect give @s minecraft:slow_falling 1 1 true
execute as @s at @s run execute as @e[distance=0.1..10] run effect give @s minecraft:weakness 1 0 true
execute as @s at @s run execute as @e[type=minecraft:trident,distance=0.1..4] at @s run data merge entity @s {Motion:[0.0,0.0,0.0]}
execute as @s at @s run execute as @e[type=minecraft:item,distance=0.1..5] at @s run data merge entity @s {Motion:[0.0,0.039,0.0]}
execute as @s at @s run execute as @e[type=minecraft:arrow,distance=0.1..4] at @s run data merge entity @s {Motion:[0.0,0.0,0.0]}
execute as @s at @s run execute as @e[type=minecraft:wither_skull,distance=0.1..5] at @s run data merge entity @s {Motion:[0.0,0.0,0.0]}
execute as @s at @s run execute as @e[type=minecraft:small_fireball,distance=0.1..5] at @s run data merge entity @s {Motion:[0.0,0.0,0.0]}
execute as @s at @s run execute as @e[type=minecraft:dragon_fireball,distance=0.1..5] at @s run data merge entity @s {Motion:[0.0,0.0,0.0]}
execute as @s at @s run execute as @e[type=minecraft:fireball,distance=0.1..5] at @s run data merge entity @s {Motion:[0.0,0.0,0.0]}
execute as @s at @s run particle minecraft:soul_fire_flame ~ ~ ~ 10 10 10 1 50 force @a

#Old InfinityGem command: minecraft:give @p warped_fungus_on_a_stick{display:{Name:'["",{"text":"Infinity","italic":false,"color":"#cc0033"},{"text":" ","italic":false,"color":"dark_blue"},{"text":"Gem","italic":false,"color":"dark_aqua"}]',Lore:['["",{"text":"You ","italic":false,"color":"#cc0033"},{"text":"have","italic":false,"color":"dark_aqua"}]','["",{"text":"Saturo ","italic":false,"color":"#cc0033"},{"text":"Gojo","italic":false,"color":"dark_aqua"}]','["",{"text":"infinity ","italic":false,"color":"#cc0033"},{"text":"ability","italic":false,"color":"dark_aqua"}]']},Enchantments:[{}],CustomModelData:10,AttributeModifiers:[{AttributeName:"generic.armor",Amount:-100,Slot:mainhand,UUID:[I;-124731,13502,145410,-27004],Name:1725112541495},{AttributeName:"generic.armor",Amount:-100,Slot:offhand,UUID:[I;-124731,13802,145410,-27604],Name:1725112541495}],HideFlags:2}


#if i make it so it executes as the player holding the gem and that player makes it execute as other players around maybe inf for players something like this:
#execute as @e[holding gem,distance=3] as @a run tp @s ^ ^ ^-0.001