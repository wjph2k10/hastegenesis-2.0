clear @s minecraft:poisonous_potato[minecraft:item_model="hastegenesis:aqua_gem"]
function hastegenesis:gems/give/aqua