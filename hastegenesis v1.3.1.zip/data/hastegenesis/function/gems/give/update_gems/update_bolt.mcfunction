clear @s minecraft:poisonous_potato[minecraft:item_model="hastegenesis:bolt_gem"]
function hastegenesis:gems/give/bolt