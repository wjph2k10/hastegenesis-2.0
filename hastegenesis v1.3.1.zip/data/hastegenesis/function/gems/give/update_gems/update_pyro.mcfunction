clear @s minecraft:poisonous_potato[minecraft:item_model="hastegenesis:pyro_gem"]
function hastegenesis:gems/give/pyro