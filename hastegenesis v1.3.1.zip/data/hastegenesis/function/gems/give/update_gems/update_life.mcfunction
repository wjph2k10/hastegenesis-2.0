clear @s minecraft:poisonous_potato[minecraft:item_model="hastegenesis:life_gem"]
function hastegenesis:gems/give/life