clear @s minecraft:poisonous_potato[minecraft:item_model="hastegenesis:vigor_gem"]
function hastegenesis:gems/give/vigor