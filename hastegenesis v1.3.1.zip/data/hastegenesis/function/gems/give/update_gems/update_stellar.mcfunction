clear @s minecraft:poisonous_potato[minecraft:item_model="hastegenesis:stellar_gem"]
function hastegenesis:gems/give/stellar