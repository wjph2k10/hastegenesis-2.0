clear @s minecraft:poisonous_potato[minecraft:item_model="hastegenesis:placeholder_gem"]
function hastegenesis:gems/give/placeholder