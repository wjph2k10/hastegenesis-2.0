execute as @a if items entity @s container.* minecraft:poisonous_potato[minecraft:item_model="hastegenesis:pyro_gem"] run function hastegenesis:gems/give/update_gems/update_pyro
execute as @a if items entity @s container.* minecraft:poisonous_potato[minecraft:item_model="hastegenesis:aqua_gem"] run function hastegenesis:gems/give/update_gems/update_aqua
execute as @a if items entity @s container.* minecraft:poisonous_potato[minecraft:item_model="hastegenesis:bolt_gem"] run function hastegenesis:gems/give/update_gems/update_bolt
execute as @a if items entity @s container.* minecraft:poisonous_potato[minecraft:item_model="hastegenesis:vigor_gem"] run function hastegenesis:gems/give/update_gems/update_vigor
execute as @a if items entity @s container.* minecraft:poisonous_potato[minecraft:item_model="hastegenesis:life_gem"] run function hastegenesis:gems/give/update_gems/update_life
execute as @a if items entity @s container.* minecraft:poisonous_potato[minecraft:item_model="hastegenesis:stellar_gem"] run function hastegenesis:gems/give/update_gems/update_stellar
execute as @a if items entity @s container.* minecraft:poisonous_potato[minecraft:item_model="hastegenesis:placeholder_gem"] run function hastegenesis:gems/give/update_gems/update_placeholder
