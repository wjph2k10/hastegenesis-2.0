execute as @e if score @s hastegenesis_ability_stellar_gem_gravity matches 1..2 run attribute @s minecraft:gravity base set 0.08
execute as @e if score @s hastegenesis_ability_stellar_gem_gravity matches 3..4 run attribute @s minecraft:gravity base set 2
execute as @e if score @s hastegenesis_ability_stellar_gem_gravity matches 1.. run scoreboard players remove @s hastegenesis_ability_stellar_gem_gravity 1
execute as @a[tag=hastegenesis_no_cooldowns] run function hastegenesis:admin/remove_cooldowns

#jjk
function hastegenesis:jjk/event/tick