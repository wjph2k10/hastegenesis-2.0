function hastegenesis:events/gems/holding_gems

schedule function hastegenesis:events/timers/19_ticks 19t
