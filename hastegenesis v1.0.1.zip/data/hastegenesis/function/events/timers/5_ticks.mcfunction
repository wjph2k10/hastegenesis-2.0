
#remove comment to activate
#schedule function hastegenesis:events/timers/5_ticks 5t