#for life gem to actually heal 1hp/s
execute as @a if score @s hastegenesis_ability_life_gem_regeneration matches ..0 run effect give @s minecraft:regeneration 2 1 true

schedule function hastegenesis:events/timers/21_ticks 21t