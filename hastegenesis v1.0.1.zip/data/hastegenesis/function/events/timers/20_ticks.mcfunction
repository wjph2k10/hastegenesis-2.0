#cooldowns
execute as @a if score @s hastegenesis_pyro_gem_right_click_cooldown matches ..0 run scoreboard players remove @a hastegenesis_pyro_gem_right_click_cooldown 1
execute as @a if score @s hastegenesis_aqua_gem_right_click_cooldown matches ..0 run scoreboard players remove @a hastegenesis_aqua_gem_right_click_cooldown 1
execute as @a if score @s hastegenesis_bolt_gem_right_click_cooldown matches ..0 run scoreboard players remove @a hastegenesis_bolt_gem_right_click_cooldown 1
execute as @a if score @s hastegenesis_vigor_gem_right_click_cooldown matches ..0 run scoreboard players remove @a hastegenesis_vigor_gem_right_click_cooldown 1
execute as @a if score @s hastegenesis_life_gem_right_click_cooldown matches ..0 run scoreboard players remove @a hastegenesis_life_gem_right_click_cooldown 1
execute as @a if score @s hastegenesis_stellar_gem_right_click_cooldown matches ..0 run scoreboard players remove @a hastegenesis_stellar_gem_right_click_cooldown 1
execute as @a if score @s hastegenesis_placeholder_gem_right_click_cooldown matches ..0 run scoreboard players remove @a hastegenesis_placeholder_gem_right_click_cooldown 1

execute as @a if score @s hastegenesis_pyro_gem_left_click_cooldown matches ..0 run scoreboard players remove @a hastegenesis_pyro_gem_left_click_cooldown 1
execute as @a if score @s hastegenesis_aqua_gem_left_click_cooldown matches ..0 run scoreboard players remove @a hastegenesis_aqua_gem_left_click_cooldown 1
execute as @a if score @s hastegenesis_bolt_gem_left_click_cooldown matches ..0 run scoreboard players remove @a hastegenesis_bolt_gem_left_click_cooldown 1
execute as @a if score @s hastegenesis_vigor_gem_left_click_cooldown matches ..0 run scoreboard players remove @a hastegenesis_vigor_gem_left_click_cooldown 1
execute as @a if score @s hastegenesis_life_gem_left_click_cooldown matches ..0 run scoreboard players remove @a hastegenesis_life_gem_left_click_cooldown 1
execute as @a if score @s hastegenesis_stellar_gem_left_click_cooldown matches ..0 run scoreboard players remove @a hastegenesis_stellar_gem_left_click_cooldown 1
execute as @a if score @s hastegenesis_placeholder_gem_left_click_cooldown matches ..0 run scoreboard players remove @a hastegenesis_placeholder_gem_left_click_cooldown 1
execute as @a if score @s hastegenesis_ability_life_gem_regeneration matches ..0 run scoreboard players remove @a hastegenesis_ability_life_gem_regeneration 1

schedule function hastegenesis:events/timers/20_ticks 20t
