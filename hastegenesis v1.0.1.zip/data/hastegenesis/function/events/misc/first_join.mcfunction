tellraw @a "Welcome to hastegenesis"
scoreboard players set @s hastegenesis_0 0
scoreboard players set @s hastegenesis_pyro_gem_right_click_cooldown 0
scoreboard players set @s hastegenesis_pyro_gem_right_click_cooldown 0
scoreboard players set @s hastegenesis_aqua_gem_right_click_cooldown 0
scoreboard players set @s hastegenesis_bolt_gem_right_click_cooldown 0
scoreboard players set @s hastegenesis_vigor_gem_right_click_cooldown 0
scoreboard players set @s hastegenesis_life_gem_right_click_cooldown 0
scoreboard players set @s hastegenesis_stellar_gem_right_click_cooldown 0
scoreboard players set @s hastegenesis_placeholder_gem_right_click_cooldown 0

scoreboard players set @s hastegenesis_pyro_gem_left_click_cooldown 0
scoreboard players set @s hastegenesis_aqua_gem_left_click_cooldown 0
scoreboard players set @s hastegenesis_bolt_gem_left_click_cooldown 0
scoreboard players set @s hastegenesis_vigor_gem_left_click_cooldown 0
scoreboard players set @s hastegenesis_life_gem_left_click_cooldown 0
scoreboard players set @s hastegenesis_stellar_gem_left_click_cooldown 0
scoreboard players set @s hastegenesis_placeholder_gem_left_click_cooldown 0
