advancement revoke @s only hastegenesis:right_click_gem_roller_gem
execute if items entity @s weapon.* minecraft:poisonous_potato[minecraft:custom_data={pyro:1b}] run function hastegenesis:gems/give/pyro
execute if items entity @s weapon.* minecraft:poisonous_potato[minecraft:custom_data={aqua:1b}] run function hastegenesis:gems/give/aqua
execute if items entity @s weapon.* minecraft:poisonous_potato[minecraft:custom_data={bolt:1b}] run function hastegenesis:gems/give/bolt
execute if items entity @s weapon.* minecraft:poisonous_potato[minecraft:custom_data={vigor:1b}] run function hastegenesis:gems/give/vigor
execute if items entity @s weapon.* minecraft:poisonous_potato[minecraft:custom_data={life:1b}] run function hastegenesis:gems/give/life
execute if items entity @s weapon.* minecraft:poisonous_potato[minecraft:custom_data={stellar:1b}] run function hastegenesis:gems/give/stellar
tellraw @a "rolled"