execute as @s at @s if entity @s run execute positioned ~ ~ ~ if block ~ ~ ~ water run effect give @s minecraft:conduit_power 1 9 true
execute as @s at @s if entity @s run execute positioned ~ ~ ~ if block ~ ~ ~ water run effect give @s minecraft:dolphins_grace 1 9 true
execute as @s at @s if entity @s run execute positioned ~ ~ ~ if block ~ ~ ~ water run effect give @s minecraft:strength 1 1 true

title @a actionbar ["",{text:"Left click cooldown: ",color:"green"},{score:{name:"@p",objective:"hastegenesis_aqua_gem_left_click_cooldown"},color:"dark_purple"},{text:" | ",bold:true,color:"blue"},{text:"Right click cooldown: ",color:"green"},{score:{name:"@p",objective:"hastegenesis_aqua_gem_right_click_cooldown"},color:"dark_purple"}]

#Old WaterGem command: minecraft:give @p warped_fungus_on_a_stick{display:{Name:'["",{"text":"Water Gem","italic":false,"color":"dark_blue"}]',Lore:['["",{"text":"A Gem that","italic":false,"color":"dark_blue"}]','["",{"text":"empowers you","italic":false,"color":"dark_blue"}]','["",{"text":"underwater","italic":false,"color":"dark_blue"}]']},Enchantments:[{}],CustomModelData:8}
