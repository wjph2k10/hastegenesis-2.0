execute as @s run effect give @s minecraft:resistance 1 9 true

title @a actionbar ["",{text:"Left click cooldown: ",color:"green"},{score:{name:"@p",objective:"hastegenesis_placeholder_gem_left_click_cooldown"},color:"dark_purple"},{text:" | ",bold:true,color:"blue"},{text:"Right click cooldown: ",color:"green"},{score:{name:"@p",objective:"hastegenesis_placeholder_gem_right_click_cooldown"},color:"dark_purple"}]

#Old ImmortalityGem command: minecraft:give @p warped_fungus_on_a_stick{display:{Name:'["",{"text":"Immortality Gem","italic":false,"color":"dark_green"}]',Lore:['["",{"text":"A Gem that makes","italic":false,"color":"dark_green"}]','["",{"text":"you immortal ","italic":false,"color":"dark_green"},{"text":"but","italic":false,"color":"dark_green"}]','["",{"text":"at what cost...","italic":false,"color":"dark_green"}]']},Enchantments:[{}],CustomModelData:6}
