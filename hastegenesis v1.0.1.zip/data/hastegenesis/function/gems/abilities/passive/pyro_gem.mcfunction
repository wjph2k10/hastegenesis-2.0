execute as @s run effect give @s minecraft:fire_resistance 1 0 true

title @a actionbar ["",{text:"Left click cooldown: ",color:"green"},{score:{name:"@p",objective:"hastegenesis_pyro_gem_left_click_cooldown"},color:"dark_purple"},{text:" | ",bold:true,color:"blue"},{text:"Right click cooldown: ",color:"green"},{score:{name:"@p",objective:"hastegenesis_pyro_gem_right_click_cooldown"},color:"dark_purple"}]

#Old FireGem command: minecraft:give @p warped_fungus_on_a_stick{display:{Name:'["",{"text":"Fire Gem","italic":false,"color":"gold"}]',Lore:['["",{"text":"A Gem that","italic":false,"color":"gold"}]','["",{"text":"Harness\'s","italic":false,"color":"gold"}]','["",{"text":"the flames","italic":false,"color":"gold"}]','["",{"text":"Hold to shoot","italic":false,"color":"gray"}]']},Enchantments:[{}],CustomModelData:1}
