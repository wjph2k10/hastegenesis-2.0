advancement revoke @s only hastegenesis:right_click_aqua_gem

execute if score @s hastegenesis_aqua_gem_right_click_cooldown matches ..00 run return fail
scoreboard players set @s hastegenesis_aqua_gem_right_click_cooldown 10

#tellraw @a "right clicked aqua"