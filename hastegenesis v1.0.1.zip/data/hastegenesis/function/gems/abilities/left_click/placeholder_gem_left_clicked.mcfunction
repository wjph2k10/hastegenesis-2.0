execute if score @s hastegenesis_placeholder_gem_left_click_cooldown matches ..00 run return fail
scoreboard players set @s hastegenesis_placeholder_gem_left_click_cooldown 10

#tellraw @a "left clicked placeholder"