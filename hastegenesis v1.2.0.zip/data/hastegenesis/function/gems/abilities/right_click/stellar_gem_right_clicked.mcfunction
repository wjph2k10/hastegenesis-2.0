advancement revoke @s only hastegenesis:right_click_stellar_gem

execute if score @s[tag=!hastegenesis_no_cooldowns] hastegenesis_cooldown_stellar_gem_right_click matches 1.. run return fail
scoreboard players set @s hastegenesis_cooldown_stellar_gem_right_click 5

execute if score @s hastegenesis_ability_stellar_gem_no_gravity_toggle matches 0 run attribute @s minecraft:gravity base set 0.04
execute if score @s hastegenesis_ability_stellar_gem_no_gravity_toggle matches 0 run return run scoreboard players set @s hastegenesis_ability_stellar_gem_no_gravity_toggle 1

execute if score @s hastegenesis_ability_stellar_gem_no_gravity_toggle matches 1 run attribute @s minecraft:gravity base set 0.08
execute if score @s hastegenesis_ability_stellar_gem_no_gravity_toggle matches 1 run return run scoreboard players set @s hastegenesis_ability_stellar_gem_no_gravity_toggle 0

#tellraw @a "right clicked stellar"