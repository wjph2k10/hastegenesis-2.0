execute if score @s[tag=!hastegenesis_no_cooldowns] hastegenesis_cooldown_life_gem_left_click matches 1.. run return fail
scoreboard players set @s hastegenesis_cooldown_life_gem_left_click 300


execute as @e[distance=0.01..15] run damage @s 5 minecraft:magic

execute as @s at @s store result score @s hastegenesis_ability_life_gem_absorption if entity @e[distance=0.01..15]
execute as @s run scoreboard players remove @s hastegenesis_ability_life_gem_absorption 1
execute store result storage hastegenesis:number_of_entities_nearby number int 0.5 run scoreboard players get @s hastegenesis_ability_life_gem_absorption
execute as @s run function hastegenesis:gems/abilities/left_click/life_gem_siphon with storage hastegenesis:number_of_entities_nearby