tellraw @a "Welcome to hastegenesis"
scoreboard players set @s hastegenesis_cooldown_pyro_gem_right_click 0
scoreboard players set @s hastegenesis_cooldown_pyro_gem_right_click 0
scoreboard players set @s hastegenesis_cooldown_aqua_gem_right_click 0
scoreboard players set @s hastegenesis_cooldown_bolt_gem_right_click 0
scoreboard players set @s hastegenesis_cooldown_vigor_gem_right_click 0
scoreboard players set @s hastegenesis_cooldown_life_gem_right_click 0
scoreboard players set @s hastegenesis_cooldown_stellar_gem_right_click 0
scoreboard players set @s hastegenesis_cooldown_placeholder_gem_right_click 0

scoreboard players set @s hastegenesis_cooldown_pyro_gem_left_click 0
scoreboard players set @s hastegenesis_cooldown_aqua_gem_left_click 0
scoreboard players set @s hastegenesis_cooldown_bolt_gem_left_click 0
scoreboard players set @s hastegenesis_cooldown_vigor_gem_left_click 0
scoreboard players set @s hastegenesis_cooldown_life_gem_left_click 0
scoreboard players set @s hastegenesis_cooldown_stellar_gem_left_click 0
scoreboard players set @s hastegenesis_cooldown_placeholder_gem_left_click 0
