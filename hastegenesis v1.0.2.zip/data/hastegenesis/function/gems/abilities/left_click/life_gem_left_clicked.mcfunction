execute if score @s hastegenesis_life_gem_left_click_cooldown matches 1.. run return fail
scoreboard players set @s hastegenesis_life_gem_left_click_cooldown 10

#scoreboard players set @s hastegenesis_ability_life_gem_saturation 10

#tellraw @a "left clicked life"