execute if score @s hastegenesis_bolt_gem_left_click_cooldown matches 1.. run return fail
scoreboard players set @s hastegenesis_bolt_gem_left_click_cooldown 10

#tellraw @a "left clicked bolt"