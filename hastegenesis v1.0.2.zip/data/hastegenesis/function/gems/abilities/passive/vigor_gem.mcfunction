execute as @s run effect give @s minecraft:strength 1 1 true
execute as @s run effect give @s minecraft:jump_boost 1 1 true

execute if score @s hastegenesis_vigor_gem_left_click_cooldown matches 0 if score @s hastegenesis_vigor_gem_right_click_cooldown matches 0 run title @s actionbar ["",{"text":"Left click cooldown: ","color":"green"},{"text":"READY","color":"dark_purple"},{"text":" | ","bold":true,"color":"blue"},{"text":"Right click cooldown: ","color":"green"},{"text":"READY","color":"dark_purple"}]

execute if score @s hastegenesis_vigor_gem_left_click_cooldown matches 0 if score @s hastegenesis_vigor_gem_right_click_cooldown matches 0 run title @s actionbar ["",{"text":"Left click cooldown: ","color":"green"},{"text":"READY","color":"dark_purple"},{"text":" | ","bold":true,"color":"blue"},{"text":"Right click cooldown: ","color":"green"},{"text":"READY","color":"dark_purple"}]

execute unless score @s hastegenesis_vigor_gem_left_click_cooldown matches 0 if score @s hastegenesis_vigor_gem_right_click_cooldown matches 0 run title @s actionbar ["",{"text":"Left click cooldown: ","color":"green"},{"score":{"name":"@s","objective":"hastegenesis_vigor_gem_left_click_cooldown"},"color":"dark_purple"},{"text":" | ","bold":true,"color":"blue"},{"text":"Right click cooldown: ","color":"green"},{"text":"READY","color":"dark_purple"}]

execute unless score @s hastegenesis_vigor_gem_left_click_cooldown matches 0 unless score @s hastegenesis_vigor_gem_right_click_cooldown matches 0 run title @s actionbar ["",{"text":"Left click cooldown: ","color":"green"},{"score":{"name":"@s","objective":"hastegenesis_vigor_gem_left_click_cooldown"},"color":"dark_purple"},{"text":" | ","bold":true,"color":"blue"},{"text":"Right click cooldown: ","color":"green"},{"score":{"name":"@s","objective":"hastegenesis_vigor_gem_right_click_cooldown"},"color":"dark_purple"}]

#Old StrengthGem command: minecraft:give @p minecraft:warped_fungus_on_a_stick{display:{Name:'["",{"text":"Strength Gem","italic":false,"color":"dark_red"}]',Lore:['["",{"text":"A Gem that","italic":false,"color":"dark_red"}]','["",{"text":"Strengthens","italic":false,"color":"dark_red"}]','["",{"text":"you","italic":false,"color":"dark_red"}]']},Enchantments:[{}],CustomModelData:4}
