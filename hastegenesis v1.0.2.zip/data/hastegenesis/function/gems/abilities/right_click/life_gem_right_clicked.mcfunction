advancement revoke @s only hastegenesis:right_click_life_gem


execute if score @s hastegenesis_life_gem_right_click_cooldown matches 1.. run return fail
scoreboard players set @s hastegenesis_life_gem_right_click_cooldown 60


scoreboard players set @s hastegenesis_ability_life_gem_saturation 4
#scoreboard players set @s hastegenesis_ability_life_gem_regeneration 5


#tellraw @a "right clicked life"