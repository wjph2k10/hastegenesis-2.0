advancement revoke @s only hastegenesis:right_click_bolt_gem

execute if score @s hastegenesis_bolt_gem_right_click_cooldown matches 1.. run return fail
scoreboard players set @s hastegenesis_bolt_gem_right_click_cooldown 10

#tellraw @a "right clicked bolt"