advancement revoke @s only hastegenesis:right_click_pyro_gem

execute if score @s hastegenesis_pyro_gem_right_click_cooldown matches 1.. run return fail
scoreboard players set @s hastegenesis_pyro_gem_right_click_cooldown 10

execute as @e[type=#hastegenesis:ignitable_hostile_enemies,distance=0.01..5,nbt=!{Health:0F}] run data merge entity @s {Fire:200}

#tellraw @a "right clicked pyro"