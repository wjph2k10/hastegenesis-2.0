execute as @s run effect give @s minecraft:strength 1 1 true
execute as @s run effect give @s minecraft:jump_boost 1 1 true

#Old StrengthGem command: minecraft:give @p minecraft:warped_fungus_on_a_stick{display:{Name:'["",{"text":"Strength Gem","italic":false,"color":"dark_red"}]',Lore:['["",{"text":"A Gem that","italic":false,"color":"dark_red"}]','["",{"text":"Strengthens","italic":false,"color":"dark_red"}]','["",{"text":"you","italic":false,"color":"dark_red"}]']},Enchantments:[{}],CustomModelData:4}
