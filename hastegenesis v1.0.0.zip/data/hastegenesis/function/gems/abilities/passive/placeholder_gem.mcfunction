execute as @s run effect give @s minecraft:resistance 1 9 true


#Old ImmortalityGem command: minecraft:give @p warped_fungus_on_a_stick{display:{Name:'["",{"text":"Immortality Gem","italic":false,"color":"dark_green"}]',Lore:['["",{"text":"A Gem that makes","italic":false,"color":"dark_green"}]','["",{"text":"you immortal ","italic":false,"color":"dark_green"},{"text":"but","italic":false,"color":"dark_green"}]','["",{"text":"at what cost...","italic":false,"color":"dark_green"}]']},Enchantments:[{}],CustomModelData:6}
