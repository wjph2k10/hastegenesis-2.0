execute as @s run effect give @s minecraft:resistance 1 0 true

#Old SupportGem command: minecraft:give @p warped_fungus_on_a_stick{display:{Name:'["",{"text":"Support Gem","italic":false,"color":"light_purple"}]',Lore:['["",{"text":"A Gem that","italic":false,"color":"light_purple"}]','["",{"text":"buffs players","italic":false,"color":"light_purple"}]','["",{"text":"around you","italic":false,"color":"light_purple"}]']},Enchantments:[{}],CustomModelData:2}
