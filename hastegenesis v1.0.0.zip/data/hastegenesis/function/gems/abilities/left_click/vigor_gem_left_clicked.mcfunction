execute if score @s hastegenesis_vigor_gem_left_click_cooldown > @s hastegenesis_0 run return fail
scoreboard players set @s hastegenesis_vigor_gem_left_click_cooldown 10

#tellraw @a "left clicked vigor"