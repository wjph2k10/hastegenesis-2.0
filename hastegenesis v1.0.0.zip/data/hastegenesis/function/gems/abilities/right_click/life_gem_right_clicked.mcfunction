advancement revoke @s only hastegenesis:right_click_life_gem

execute if score @s hastegenesis_life_gem_right_click_cooldown > @s hastegenesis_0 run return fail
scoreboard players set @s hastegenesis_life_gem_right_click_cooldown 10
scoreboard players set @s hastegenesis_ability_life_gem_regeneration 5

#tellraw @a "right clicked life"